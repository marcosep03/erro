package com.example.sistemadeportaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemadeportariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
