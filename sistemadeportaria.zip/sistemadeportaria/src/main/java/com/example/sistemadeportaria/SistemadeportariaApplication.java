package com.example.sistemadeportaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemadeportariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemadeportariaApplication.class, args);
	}

}
